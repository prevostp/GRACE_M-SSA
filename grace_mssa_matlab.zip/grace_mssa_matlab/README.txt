README for grace_mssa_matlab.zip

The folder contains :
	- grid_mssa.mat
	- README.txt
	
grid_mssa.mat is a Matlab file that can be open in matlab via the 
command "load grid_mssa.mat"

grid_mssa.mat consists of: 	- ewh_grid (180*360*162 : montlhy equivalent
								water height (in cm) GRACE global grids
							- Lat (1*180): latitude
							- Lon (1*360): longitude
							- T (162*3): time vector (yyyy.yyyy year doy)
							
When using these data, please cite :
Prevost, P., Chanard, K., Fleitout, L., Calais, E., Walwer, D., van Dam,
T., & Ghil, M. (2019). Data-adaptive spatio-temporal filtering of GRACE
data. Geophysical Journal International, 219(3), 2034-2055.
