README for grace_mssa_grids.zip

The folder contains :
	- ewh_grid folder
	- README.txt
	
The folder ewh_grid contains 162 equivalent water height (in cm) GRACE 
global grids.

The name of each file is "grace_yeardoy_mssa.txt" with year and doy the
date of the beginning of the month.

Every file has 3 columns: longitude latitude ewh(in cm)
							
When using these data, please cite :
Prevost, P., Chanard, K., Fleitout, L., Calais, E., Walwer, D., van Dam,
T., & Ghil, M. (2019). Data-adaptive spatio-temporal filtering of GRACE
data. Geophysical Journal International, 219(3), 2034-2055.
